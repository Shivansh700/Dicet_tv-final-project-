import { useState } from 'react'
import '../Css/Div1.css'

const ServiceBox = ({ boxClassName, imgSrc, imgAlt, heading, headingColor, text, textColor }) => (
  <div className={boxClassName}>
    <img src={imgSrc} alt={imgAlt} />
    <h2 style={{ color: headingColor }}>{heading}</h2>
    <h5 style={{ color: textColor }}>{text}</h5>
  </div>
);


const Div1 = () => {
  return (
    <>
<div className="layer1">
  <div className="layer2">
    <nav className="header">
      <div className="left">
        <p className="p1" style={{ color: "white" }}>
          Dicet
        </p>
        <p className="p1" style={{ color: "black" }}>
          Tv
        </p>
      </div>
      <div className="center">
        <a href="#home">• HOME</a>
        <a href="#about">• ABOUT</a>
        <a href="#product">• PRODUCT</a>
        <a href="#blog">• BLOG</a>
        <a href="#contact">• CONTACT US</a>
        <button>GET STARTED</button>
      </div>
      <div className="right">
        <img src="images/man-user.png" alt="user" />
        <img src="images/shopping-bag.png" alt="bag" />
        <img src="images/search.png" alt="search" />
      </div>
      <div className="ham-menu">
        <span />
        <span />
        <span />
      </div>
      <div className="hamburger-items">
        <ul>
          <li>HOME</li>
          <li>ABOUT</li>
          <li>PRODUCT</li>
          <li>BLOG</li>
          <li>CONTACT US</li>
        </ul>
      </div>
    </nav>
    <div className="section1">
      <div className="div-arrows">
        <button>
          <img src="images/left-arrow.png" />
        </button>
        <button>
          <img src="images/right-arrow.png" />
        </button>
      </div>
      <div className="div1">
        <h3>Your Favourite</h3>
        <h1>Shows And Movies</h1>
        <h5>
          There are many variations of passages of Lorem Ipsum available, but
          majority have
          <br /> suffered alteration in some form, by injected humour, or
        </h5>
        <button className="button1">Start Now</button>
        <button className="button2">Read More</button>
      </div>
      <div className="div2">
        <img src="images/streamer.png" alt="box" />
        <div className="DicetTv">
          <p className="p1" style={{ color: "white" }}>
            Dicet
          </p>
          <p className="p1" style={{ color: "white" }}>
            Tv
          </p>
        </div>
      </div>
    </div>
    <div className="section2">
    <ServiceBox 
      boxClassName="box1"
      imgSrc="images/world-wide-internet-signal.png"
      imgAlt="web"
      heading="Broadband"
      headingColor="white"
      text="There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, m Ipsum, you need to be"
      textColor="white"
    />
    <ServiceBox 
      boxClassName="box2"
      imgSrc="images/television.png"
      imgAlt="tv"
      heading="Satelite TV"
      headingColor="black"
      text="There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, m Ipsum, you need to be"
      textColor="black"
    />
    <ServiceBox 
      boxClassName="box3"
      imgSrc="images/hand-graving-smartphone.png"
      imgAlt="phone"
      heading="Mobility"
      headingColor="white"
      text="There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, m Ipsum, you need to be"
      textColor="white"
    />
  </div>
  </div>
</div>



    </>
  )
}

export default Div1
