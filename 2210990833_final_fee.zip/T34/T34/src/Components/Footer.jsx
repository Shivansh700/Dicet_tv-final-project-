import { useState } from 'react'
import '../Css/Footer.css'
const Footer = () => {
  return (
    <>
<footer>
  <div id='contact' className="bigdiv">
    <div className="div11">
      <h1 className="h1-footer">Dicet TV</h1>
      <h2>CUSTOMER SERVICE</h2>
      <h3>
        There are many variat
        <br />
        ions of passages of L<br />
        orem Ipsum available
        <br />
        , but the majority h<br />
        ave suffered altera
        <br />
        tion in some form, by
        <br />{" "}
      </h3>
    </div>
    <div className="div2">
      <h2>LET US HELP YOU</h2>
      <h3>
        There are many variat
        <br />
        ions of passages of L<br />
        orem Ipsum available
        <br />
        , but the majority h<br />
        ave suffered altera
        <br />
        tion in some form, by <br />
      </h3>
    </div>
    <div className="div3">
      <h2>INFORMATION</h2>
      <h3>
        About Us
        <br />
        Careers
        <br />
        Sell on shopee
        <br />
        Press &amp; News
        <br />
        Competitions
        <br />
        Terms &amp; Conditions
        <br />
      </h3>
    </div>
    <div className="div4">
      <h2>OUR SHOP</h2>
      <h3>
        There are many variat
        <br />
        ions of passages of L<br />
        orem Ipsum available
        <br />
        , but the majority h<br />
        ave suffered altera
        <br />
        tion in some form, by
        <br />{" "}
      </h3>
      <div className="icon">
        <img src="images/facebook-logo-button.png" alt="" />
        <img src="images/twitter.png" alt="" />
        <img src="images/instagram.png" alt="" />
        <img src="images/linkedin-logo-button.png" alt="" />
      </div>
    </div>
  </div>
  <footer className="foot">
    <p>© 2019 All Rights Reserved. Design by Free Html Templates</p>
  </footer>
</footer>


    </>
  )
}

export default Footer
