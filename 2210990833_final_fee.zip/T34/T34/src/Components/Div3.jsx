import React from 'react'
import { useState } from 'react'
import '../Css/Div3.css'

const PlanCard = ({ cardClassName, heading, subheading, price, description, buttonText }) => (
  <div className={cardClassName}>
    <h3>{heading}</h3>
    <p>{subheading}</p>
    <h1>{price}</h1>
    <h4>{description}</h4>
    <button className="button0">{buttonText}</button>
  </div>
);

const Div3 = () => {
  return (
    <>
<div id='product' className="page3">
  <img className="tariffs" src="images/Tariffs .png" alt="text" />
  <h3>Choose your plans</h3>
  <p>
    Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin bibendum, est
    ac faucibus hendrerit, mauris ante viverra urna, in elementum urna est ut
    ligula.
  </p>
  <div className="outer">
    <PlanCard 
      cardClassName="div1"
      heading="Easy Surfing"
      subheading="INTERNET"
      price="$24.99"
      description="It is a long established fact that a reader will be distracted by the readable content."
      buttonText="SEE MORE"
    />
    <PlanCard 
      cardClassName="div2"
      heading="Impression"
      subheading="TV"
      price="$24.99"
      description="It is a long established fact that a reader will be distracted by the readable content."
      buttonText="SEE MORE"
    />
    <PlanCard 
      cardClassName="div3"
      heading="Premium Plans"
      subheading="INTERNET + TV + PHONE"
      price="$24.99"
      description="It is a long established fact that a reader will be distracted by the readable content."
      buttonText="SEE MORE"
    />
  </div>
  
</div>



    </>
  )
}

export default Div3
