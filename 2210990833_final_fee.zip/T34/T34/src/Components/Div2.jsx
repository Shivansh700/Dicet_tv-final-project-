import React from 'react'
import { useState } from 'react'
import '../Css/Div2.css'
const Div2 = () => {
  return (
    <>
<div id='about' className="page2">
  <img
    className="dot1"
    src="images/Dot-PNG-Dot-Transparent-Clipart-715x715.png"
    alt="dots"
  />
  <img
    className="dot2"
    src="images/Dot-PNG-Dot-Transparent-Clipart-715x715 copy.png"
    alt="dots"
  />
  <div className="div1" />
  <div className="div2">
    <h1>Live Sport and TV-shows for best friends</h1>
    <h5>
      It is a long established fact that a reader will be distracted by the
      readable content of a page when looking at its layout. The point of using
      Lorem Ipsum is that it has a more-or-less normal distribution of letters,
    </h5>
    <button className="button1">4K Ultra HD Quality</button>
    <button className="button2">200+ Online Channels</button>
    <button className="button3">READ MORE</button>
  </div>
</div>

    </>
  )
}

export default Div2
