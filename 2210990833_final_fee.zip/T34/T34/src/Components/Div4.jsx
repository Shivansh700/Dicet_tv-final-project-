import React from 'react'
import { useState } from 'react'
import '../Css/Div4.css'
const Div4 = ({ imageUrl, title, description }) => {
  return (
<>
  <div className="page4">
    <h1>Check ability to connect our services in your area</h1>
    <img className="map" src="images/world_map_PNG28.png" alt="map" />
    <img className="ellipse" src="images/Ellipse3.png" alt="red-ellipse" />
    <h4>IT IS A LONG ESTABLISHED FACT THAT A READER WILL BE DISTRACTED</h4>
    <img className="line" src="images/Shape1.png" alt="line" />
    <input type="text" placeholder="Enter your address" />
    <button>GET STARTED</button>
  </div>
  <section>
    <div id='blog' className="page5">
      <h1>What our clients say</h1>
      <img className="ellipse4" src="images/Ellipse4.png" alt="ellipse4" />
      <img className="user" src="images/man-user2.png" alt="icon" />
      <h2>Miller</h2>
      <p>
        ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor
        incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
        quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
        consequat. Duis aute irure dolor in reprehenderit in voluptate velit
        esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat
        cupidatat non proident, sunt in culpa qui officia deserunt mollit anim
        id
      </p>
      <img className="quote" src="images/quote.png" alt="quote" />
    </div>
    <div className="subscribe">
      <p className="text">Subscribe Now</p>
      <input type="text" placeholder="Enter your email" />
      <button>SUBSCRIBE</button>
    </div>
  </section>
</>


  );
};

export default Div4;
